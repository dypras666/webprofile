import './bootstrap';
import Sortable from 'sortablejs';

// Make Sortable globally available
window.Sortable = Sortable;