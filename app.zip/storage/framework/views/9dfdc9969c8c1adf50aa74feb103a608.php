<?php $__env->startSection('title'); ?>
    <?php if(request('category')): ?>
        <?php echo e($category->name ?? 'Category'); ?> - <?php switch(request('type')):
            case ('page'): ?>
                Pages
                <?php break; ?>
            <?php case ('video'): ?>
                Videos
                <?php break; ?>
            <?php case ('gallery'): ?>
                Gallery
                <?php break; ?>
            <?php default: ?>
                Articles
        <?php endswitch; ?>
    <?php elseif(request('type')): ?>
        <?php switch(request('type')):
            case ('page'): ?>
                Pages
                <?php break; ?>
            <?php case ('video'): ?>
                Videos
                <?php break; ?>
            <?php case ('gallery'): ?>
                Gallery
                <?php break; ?>
            <?php default: ?>
                <?php echo e(ucfirst(request('type'))); ?> Articles
        <?php endswitch; ?>
    <?php elseif(request('search')): ?>
        Search Results for "<?php echo e(request('search')); ?>"
    <?php else: ?>
        All Articles
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_description'); ?>
    <?php if(request('category')): ?>
        Browse <?php echo e($category->name ?? 'category'); ?> <?php switch(request('type')):
            case ('page'): ?>
                pages
                <?php break; ?>
            <?php case ('video'): ?>
                videos
                <?php break; ?>
            <?php case ('gallery'): ?>
                gallery
                <?php break; ?>
            <?php default: ?>
                articles
        <?php endswitch; ?> and stay updated with the latest content.
    <?php elseif(request('search')): ?>
        Search results for "<?php echo e(request('search')); ?>" - Find relevant <?php switch(request('type')):
            case ('page'): ?>
                pages
                <?php break; ?>
            <?php case ('video'): ?>
                videos
                <?php break; ?>
            <?php case ('gallery'): ?>
                gallery
                <?php break; ?>
            <?php default: ?>
                articles and news
        <?php endswitch; ?>.
    <?php else: ?>
        Browse all <?php switch(request('type')):
            case ('page'): ?>
                pages
                <?php break; ?>
            <?php case ('video'): ?>
                videos
                <?php break; ?>
            <?php case ('gallery'): ?>
                gallery
                <?php break; ?>
            <?php default: ?>
                articles, news, and insights
        <?php endswitch; ?>. Stay informed with our comprehensive coverage.
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">
                <?php if(request('category')): ?>
                    <?php echo e($category->name ?? 'Category'); ?>

                <?php elseif(request('type')): ?>
                    <?php switch(request('type')):
                        case ('page'): ?>
                            Pages
                            <?php break; ?>
                        <?php case ('video'): ?>
                            Videos
                            <?php break; ?>
                        <?php case ('gallery'): ?>
                            Gallery
                            <?php break; ?>
                        <?php default: ?>
                            <?php echo e(ucfirst(request('type'))); ?> Articles
                    <?php endswitch; ?>
                <?php elseif(request('search')): ?>
                    Search Results
                <?php else: ?>
                    All Articles
                <?php endif; ?>
            </h1>
            
            <?php if(request('search')): ?>
                <p class="text-xl text-blue-100 mb-6">
                    Found <?php echo e($posts->total()); ?> results for "<?php echo e(request('search')); ?>"
                </p>
            <?php elseif(request('category') && isset($category)): ?>
                <p class="text-xl text-blue-100 mb-6">
                    <?php echo e($category->description ?? 'Explore '); ?>

                    <?php switch(request('type')):
                        case ('page'): ?>
                            pages
                            <?php break; ?>
                        <?php case ('video'): ?>
                            videos
                            <?php break; ?>
                        <?php case ('gallery'): ?>
                            gallery
                            <?php break; ?>
                        <?php default: ?>
                            articles
                    <?php endswitch; ?>
                    <?php echo e($category->description ? '' : ' in this category'); ?>

                </p>
            <?php else: ?>
                <p class="text-xl text-blue-100 mb-6">
                    Discover our latest <?php switch(request('type')):
                        case ('page'): ?>
                            pages
                            <?php break; ?>
                        <?php case ('video'): ?>
                            videos
                            <?php break; ?>
                        <?php case ('gallery'): ?>
                            gallery
                            <?php break; ?>
                        <?php default: ?>
                            articles, news, and insights
                    <?php endswitch; ?>
                </p>
            <?php endif; ?>
            
            
            <div class="max-w-2xl mx-auto">
                <form action="<?php echo e(route('frontend.posts')); ?>" method="GET" class="flex">
                    <?php if(request('category')): ?>
                        <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
                    <?php endif; ?>
                    <?php if(request('type')): ?>
                        <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
                    <?php endif; ?>
                    
                    <div class="flex-1 relative">
                        <input type="text" 
                               name="search" 
                               value="<?php echo e(request('search')); ?>"
                               placeholder="Search <?php switch(request('type')):
                                   case ('page'): ?>
                                       pages
                                       <?php break; ?>
                                   <?php case ('video'): ?>
                                       videos
                                       <?php break; ?>
                                   <?php case ('gallery'): ?>
                                       gallery
                                       <?php break; ?>
                                   <?php default: ?>
                                       articles
                               <?php endswitch; ?>..."
                               class="w-full px-6 py-4 rounded-l-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white/50">
                        <svg class="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </div>
                    <button type="submit" class="px-8 py-4 bg-white text-blue-600 font-semibold rounded-r-lg hover:bg-blue-50 transition-colors">
                        Search
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="bg-white border-b">
    <div class="container mx-auto px-4 py-6">
        <div class="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            
            <div class="flex flex-wrap items-center space-x-2">
                <span class="text-gray-600 font-medium mr-4">Categories:</span>
                <a href="<?php echo e(route('frontend.posts')); ?>" 
                   class="px-4 py-2 rounded-full text-sm font-medium transition-colors <?php echo e(!request('category') ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    All
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('frontend.posts', ['category' => $cat->slug])); ?>" 
                       class="px-4 py-2 rounded-full text-sm font-medium transition-colors <?php echo e(request('category') == $cat->slug ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                        <?php echo e($cat->name); ?>

                        <span class="ml-1 text-xs opacity-75">(<?php echo e($cat->posts_count); ?>)</span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            
            <div class="flex items-center space-x-4">
                <span class="text-gray-600 font-medium">Sort by:</span>
                <select onchange="updateSort(this.value)" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="latest" <?php echo e(request('sort') == 'latest' || !request('sort') ? 'selected' : ''); ?>>Latest</option>
                    <option value="popular" <?php echo e(request('sort') == 'popular' ? 'selected' : ''); ?>>Most Popular</option>
                    <option value="title" <?php echo e(request('sort') == 'title' ? 'selected' : ''); ?>>Title A-Z</option>
                </select>
            </div>
        </div>
    </div>
</div>


<main class="container mx-auto px-4 py-12">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div class="lg:col-span-2">
            <?php if($posts->count() > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow group">
                            <?php if($post->featured_image): ?>
                                <div class="relative overflow-hidden">
                                    <img src="<?php echo e($post->featured_image_url); ?>" 
                                         alt="<?php echo e($post->title); ?>"
                                         class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300">
                                    
                                    
                                    <?php if($post->category): ?>
                                        <span class="absolute top-4 left-4 bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                                            <?php echo e($post->category->name); ?>

                                        </span>
                                    <?php endif; ?>
                                    
                                    
                                    <?php if($post->is_featured): ?>
                                        <span class="absolute top-4 right-4 bg-yellow-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
                                            Featured
                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="p-6">
                                <h3 class="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                                    <a href="<?php echo e(route('frontend.post', $post->slug)); ?>" class="line-clamp-2">
                                        <?php echo e($post->title); ?>

                                    </a>
                                </h3>
                                
                                <p class="text-gray-600 mb-4 line-clamp-3">
                                    <?php echo e($post->excerpt ?: Str::limit(strip_tags($post->content), 120)); ?>

                                </p>
                                
                                
                                <div class="flex items-center justify-between text-sm text-gray-500">
                                    <div class="flex items-center space-x-4">
                                        <span class="flex items-center">
                                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path>
                                            </svg>
                                            <?php echo e($post->user->name ?? 'Admin'); ?>

                                        </span>
                                        <span class="flex items-center">
                                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                                            </svg>
                                            <?php echo e($post->created_at->format('M d, Y')); ?>

                                        </span>
                                    </div>
                                    
                                    <span class="flex items-center text-blue-600">
                                        <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"></path>
                                            <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"></path>
                                        </svg>
                                        <?php echo e($post->views ?? 0); ?>

                                    </span>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                
                <div class="flex justify-center">
                    <?php echo e($posts->appends(request()->query())->links()); ?>

                </div>
            <?php else: ?>
                
                <div class="text-center py-16">
                    <svg class="w-24 h-24 mx-auto text-gray-400 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">No <?php switch(request('type')):
                        case ('page'): ?>
                            Pages
                            <?php break; ?>
                        <?php case ('video'): ?>
                            Videos
                            <?php break; ?>
                        <?php case ('gallery'): ?>
                            Gallery
                            <?php break; ?>
                        <?php default: ?>
                            Articles
                    <?php endswitch; ?> Found</h3>
                    <p class="text-gray-600 mb-8">
                        <?php if(request('search')): ?>
                            No <?php switch(request('type')):
                                case ('page'): ?>
                                    pages
                                    <?php break; ?>
                                <?php case ('video'): ?>
                                    videos
                                    <?php break; ?>
                                <?php case ('gallery'): ?>
                                    gallery
                                    <?php break; ?>
                                <?php default: ?>
                                    articles
                            <?php endswitch; ?> match your search criteria. Try different keywords.
                        <?php else: ?>
                            There are no <?php switch(request('type')):
                                case ('page'): ?>
                                    pages
                                    <?php break; ?>
                                <?php case ('video'): ?>
                                    videos
                                    <?php break; ?>
                                <?php case ('gallery'): ?>
                                    gallery
                                    <?php break; ?>
                                <?php default: ?>
                                    articles
                            <?php endswitch; ?> in this category yet.
                        <?php endif; ?>
                    </p>
                    <a href="<?php echo e(route('frontend.posts')); ?>" class="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Browse All <?php switch(request('type')):
                            case ('page'): ?>
                                Pages
                                <?php break; ?>
                            <?php case ('video'): ?>
                                Videos
                                <?php break; ?>
                            <?php case ('gallery'): ?>
                                Gallery
                                <?php break; ?>
                            <?php default: ?>
                                Articles
                        <?php endswitch; ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        
        <div class="lg:col-span-1">
            
            <?php if($popularPosts->count() > 0): ?>
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <svg class="w-6 h-6 mr-2 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                        </svg>
                        Trending
                    </h3>
                    
                    <div class="space-y-4">
                        <?php $__currentLoopData = $popularPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-start space-x-3">
                                <span class="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                                    <?php echo e($index + 1); ?>

                                </span>
                                <div class="flex-1 min-w-0">
                                    <h4 class="text-sm font-medium text-gray-900 hover:text-blue-600 transition-colors">
                                        <a href="<?php echo e(route('frontend.post', $post->slug)); ?>" class="line-clamp-2">
                                            <?php echo e($post->title); ?>

                                        </a>
                                    </h4>
                                    <div class="flex items-center mt-1 text-xs text-gray-500">
                                        <span><?php echo e($post->created_at->format('M d')); ?></span>
                                        <span class="mx-1">•</span>
                                        <span><?php echo e($post->views ?? 0); ?> views</span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                    <svg class="w-6 h-6 mr-2 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z"></path>
                    </svg>
                    Categories
                </h3>
                
                <div class="space-y-2">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.posts', ['category' => $cat->slug])); ?>" 
                           class="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors group <?php echo e(request('category') == $cat->slug ? 'bg-blue-50 text-blue-600' : ''); ?>">
                            <span class="group-hover:text-blue-600 transition-colors">
                                <?php echo e($cat->name); ?>

                            </span>
                            <span class="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                                <?php echo e($cat->posts_count ?? 0); ?>

                            </span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.line-clamp-3 {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateSort(value) {
    const url = new URL(window.location);
    url.searchParams.set('sort', value);
    window.location.href = url.toString();
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\webprofile\resources\views/frontend/posts.blade.php ENDPATH**/ ?>