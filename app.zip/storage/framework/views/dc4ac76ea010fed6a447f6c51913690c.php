<?php $__env->startSection('title', 'Photo Gallery - Latest Images'); ?>
<?php $__env->startSection('meta_description', 'Browse our photo gallery featuring the latest images, news photos, and visual stories. Discover compelling photography and visual content.'); ?>
<?php $__env->startSection('meta_keywords', 'photo gallery, images, photos, news photos, visual stories, photography'); ?>

<?php $__env->startSection('structured_data'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ImageGallery",
  "name": "<?php echo e(config('app.name')); ?> Photo Gallery",
  "description": "Browse our photo gallery featuring the latest images, news photos, and visual stories.",
  "url": "<?php echo e(route('frontend.gallery')); ?>",
  "publisher": {
    "@type": "Organization",
    "name": "<?php echo e(config('app.name')); ?>",
    "url": "<?php echo e(url('/')); ?>"
  }
  <?php if($images->count() > 0): ?>
  ,"image": [
    <?php $__currentLoopData = $images->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    {
      "@type": "ImageObject",
      "url": "<?php echo e($image->url); ?>",
      "name": "<?php echo e($image->title ?: 'Gallery Image'); ?>",
      "description": "<?php echo e($image->description ?: 'Image from our photo gallery'); ?>"
    }<?php if(!$loop->last): ?>,<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ]
  <?php endif; ?>
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-16">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Photo Gallery</h1>
            <p class="text-xl text-purple-100 mb-8">
                Discover our collection of stunning photography and visual stories
            </p>
            
            
            <div class="flex justify-center space-x-8 text-center">
                <div>
                    <div class="text-3xl font-bold"><?php echo e($images->total()); ?></div>
                    <div class="text-purple-200">Total Images</div>
                </div>
                <div>
                    <div class="text-3xl font-bold"><?php echo e($categories->count()); ?></div>
                    <div class="text-purple-200">Categories</div>
                </div>
                <div>
                    <div class="text-3xl font-bold"><?php echo e($images->where('created_at', '>=', now()->subMonth())->count()); ?></div>
                    <div class="text-purple-200">This Month</div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="bg-white border-b sticky top-0 z-30">
    <div class="container mx-auto px-4">
        <div class="flex flex-wrap items-center justify-between py-4">
            
            <div class="flex flex-wrap items-center space-x-2 mb-4 md:mb-0">
                <span class="text-gray-600 font-medium mr-4">Categories:</span>
                <a href="<?php echo e(route('frontend.gallery')); ?>" 
                   class="px-4 py-2 rounded-full text-sm font-medium transition-colors <?php echo e(!request('category') ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    All Images
                </a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('frontend.gallery', ['category' => $category->slug])); ?>" 
                       class="px-4 py-2 rounded-full text-sm font-medium transition-colors <?php echo e(request('category') == $category->slug ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            
            <div class="flex items-center space-x-2">
                <span class="text-gray-600 font-medium">View:</span>
                <button onclick="setView('grid')" 
                        class="p-2 rounded-lg transition-colors view-toggle <?php echo e(request('view', 'grid') == 'grid' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                    </svg>
                </button>
                <button onclick="setView('masonry')" 
                        class="p-2 rounded-lg transition-colors view-toggle <?php echo e(request('view') == 'masonry' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'); ?>">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"></path>
                    </svg>
                </button>
            </div>
        </div>
    </div>
</div>


<main class="container mx-auto px-4 py-12">
    <?php if($images->count() > 0): ?>
        
        <div id="gridView" class="gallery-view <?php echo e(request('view', 'grid') == 'grid' ? '' : 'hidden'); ?>">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="group">
                        <div class="relative overflow-hidden rounded-lg bg-gray-200 aspect-square">
                            <img src="<?php echo e($post->featured_image ? asset('storage/' . $post->featured_image) : asset('images/placeholder.jpg')); ?>" 
                                 alt="<?php echo e($post->title); ?>"
                                 class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
                            
                            
                            <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                <h3 class="text-white font-semibold text-sm mb-1"><?php echo e($post->title); ?></h3>
                                <p class="text-white/80 text-xs"><?php echo e($post->created_at->format('M d, Y')); ?></p>
                                <?php if($post->category): ?>
                                    <span class="inline-block bg-purple-600 text-white text-xs px-2 py-1 rounded mt-1"><?php echo e($post->category->name); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        
        <div id="masonryView" class="gallery-view <?php echo e(request('view') == 'masonry' ? '' : 'hidden'); ?>">
            <div class="columns-1 sm:columns-2 md:columns-3 lg:columns-4 gap-6 space-y-6">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="break-inside-avoid group">
                        <div class="relative overflow-hidden rounded-lg bg-gray-200">
                            <img src="<?php echo e($post->featured_image ? asset('storage/' . $post->featured_image) : asset('images/placeholder.jpg')); ?>" 
                                 alt="<?php echo e($post->title); ?>"
                                 class="w-full h-auto group-hover:scale-105 transition-transform duration-300">
                            
                            
                            <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                <h3 class="text-white font-semibold text-sm mb-1"><?php echo e($post->title); ?></h3>
                                <p class="text-white/80 text-xs"><?php echo e($post->created_at->format('M d, Y')); ?></p>
                                <?php if($post->category): ?>
                                    <span class="inline-block bg-purple-600 text-white text-xs px-2 py-1 rounded mt-1"><?php echo e($post->category->name); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        
        <div class="flex justify-center mt-12">
            <?php echo e($images->appends(request()->query())->links()); ?>

        </div>
    <?php else: ?>
        
        <div class="text-center py-16">
            <svg class="w-24 h-24 mx-auto text-gray-400 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
            </svg>
            <h3 class="text-2xl font-bold text-gray-900 mb-4">No Images Found</h3>
            <p class="text-gray-600 mb-8">
                <?php if(request('category')): ?>
                    No images found in this category. Try browsing other categories.
                <?php else: ?>
                    The gallery is empty. Check back later for new images.
                <?php endif; ?>
            </p>
            <a href="<?php echo e(route('frontend.gallery')); ?>" class="inline-flex items-center px-6 py-3 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                View All Images
            </a>
        </div>
    <?php endif; ?>
</main>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.columns-1 { column-count: 1; }
.columns-2 { column-count: 2; }
.columns-3 { column-count: 3; }
.columns-4 { column-count: 4; }

@media (min-width: 640px) {
    .sm\:columns-2 { column-count: 2; }
}

@media (min-width: 768px) {
    .md\:columns-3 { column-count: 3; }
}

@media (min-width: 1024px) {
    .lg\:columns-4 { column-count: 4; }
}

.break-inside-avoid {
    break-inside: avoid;
    page-break-inside: avoid;
}

.aspect-square {
    aspect-ratio: 1 / 1;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function setView(view) {
    const url = new URL(window.location);
    url.searchParams.set('view', view);
    window.location.href = url.toString();
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\webprofile\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>