<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('meta_description', $post->excerpt ?: Str::limit(strip_tags($post->content), 160)); ?>
<?php $__env->startSection('meta_keywords', $post->tags ?: ($post->category ? $post->category->name : 'news, article')); ?>


<?php $__env->startSection('og_title', $post->title); ?>
<?php $__env->startSection('og_description', $post->excerpt ?: Str::limit(strip_tags($post->content), 160)); ?>
<?php $__env->startSection('og_image', $post->featured_image_url); ?>
<?php $__env->startSection('og_url', route('frontend.post', $post->slug)); ?>

<?php $__env->startSection('structured_data'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "NewsArticle",
  "headline": "<?php echo e($post->title); ?>",
  "description": "<?php echo e($post->excerpt ?: Str::limit(strip_tags($post->content), 160)); ?>",
  "url": "<?php echo e(route('frontend.post', $post->slug)); ?>",
  "datePublished": "<?php echo e($post->created_at->toISOString()); ?>",
  "dateModified": "<?php echo e($post->updated_at->toISOString()); ?>",
  "author": {
    "@type": "Person",
    "name": "<?php echo e($post->user->name ?? 'Admin'); ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "<?php echo e(config('app.name')); ?>",
    "url": "<?php echo e(url('/')); ?>"
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php echo e(route('frontend.post', $post->slug)); ?>"
  }
  <?php if($post->featured_image): ?>
  ,"image": {
    "@type": "ImageObject",
    "url": "<?php echo e($post->featured_image_url); ?>",
    "width": 1200,
    "height": 630
  }
  <?php endif; ?>
  <?php if($post->category): ?>
  ,"articleSection": "<?php echo e($post->category->name); ?>"
  <?php endif; ?>
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<nav class="bg-gray-50 py-4">
    <div class="container mx-auto px-4">
        <ol class="flex items-center space-x-2 text-sm text-gray-600">
            <li>
                <a href="<?php echo e(route('frontend.index')); ?>" class="hover:text-blue-600 transition-colors">
                    Home
                </a>
            </li>
            <li>
                <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                </svg>
            </li>
            <li>
                <a href="<?php echo e(route('frontend.posts')); ?>" class="hover:text-blue-600 transition-colors">
                    <?php switch($post->type):
                        case ('page'): ?>
                            Pages
                            <?php break; ?>
                        <?php case ('video'): ?>
                            Videos
                            <?php break; ?>
                        <?php case ('gallery'): ?>
                            Gallery
                            <?php break; ?>
                        <?php default: ?>
                            Articles
                    <?php endswitch; ?>
                </a>
            </li>
            <?php if($post->category): ?>
                <li>
                    <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                    </svg>
                </li>
                <li>
                    <a href="<?php echo e(route('frontend.category', $post->category->slug)); ?>" class="hover:text-blue-600 transition-colors">
                        <?php echo e($post->category->name); ?>

                    </a>
                </li>
            <?php endif; ?>
            <li>
                <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                </svg>
            </li>
            <li class="text-gray-900 font-medium truncate">
                <?php echo e(Str::limit($post->title, 50)); ?>

            </li>
        </ol>
    </div>
</nav>


<article class="bg-white">
    <header class="container mx-auto px-4 py-12">
        <div class="max-w-4xl mx-auto">
            
            <div class="flex items-center space-x-3 mb-6">
                <?php if($post->category): ?>
                    <span class="inline-block bg-blue-600 text-white text-sm font-semibold px-4 py-2 rounded-full">
                        <?php echo e($post->category->name); ?>

                    </span>
                <?php endif; ?>
                
                <?php if($post->is_featured): ?>
                    <span class="inline-block bg-yellow-500 text-white text-sm font-semibold px-4 py-2 rounded-full">
                        Featured
                    </span>
                <?php endif; ?>
                
                <?php if($post->is_slider): ?>
                    <span class="inline-block bg-green-500 text-white text-sm font-semibold px-4 py-2 rounded-full">
                        Trending
                    </span>
                <?php endif; ?>
            </div>
            
            
            <h1 class="text-4xl md:text-5xl font-bold text-gray-900 leading-tight mb-6">
                <?php echo e($post->title); ?>

            </h1>
            
            
            <?php if($post->excerpt): ?>
                <p class="text-xl text-gray-600 leading-relaxed mb-8">
                    <?php echo e($post->excerpt); ?>

                </p>
            <?php endif; ?>
            
            
            <div class="flex flex-col md:flex-row md:items-center md:justify-between border-t border-b border-gray-200 py-6">
                <div class="flex items-center space-x-6 mb-4 md:mb-0">
                    
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-3">
                            <?php echo e(substr($post->user->name ?? 'A', 0, 1)); ?>

                        </div>
                        <div>
                            <p class="font-semibold text-gray-900"><?php echo e($post->user->name ?? 'Admin'); ?></p>
                            <p class="text-sm text-gray-500">Author</p>
                        </div>
                    </div>
                    
                    
                    <div class="flex items-center text-gray-600">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                        </svg>
                        <div>
                            <p class="font-medium"><?php echo e($post->created_at->format('F d, Y')); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($post->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
                </div>
                
                
                <div class="flex items-center space-x-6">
                    
                    <div class="flex items-center text-gray-600">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"></path>
                            <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="font-medium"><?php echo e(number_format($post->views ?? 0)); ?> views</span>
                    </div>
                    
                    
                    <div class="flex items-center text-gray-600">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="font-medium"><?php echo e(ceil(str_word_count(strip_tags($post->content)) / 200)); ?> min read</span>
                    </div>
                    
                    
                    <button onclick="toggleShareMenu()" class="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"></path>
                        </svg>
                        Share
                    </button>
                </div>
            </div>
        </div>
    </header>
    
    
    <?php if($post->featured_image): ?>
        <div class="container mx-auto px-4 mb-12">
            <div class="max-w-4xl mx-auto">
                <img src="<?php echo e($post->featured_image_url); ?>" 
                     alt="<?php echo e($post->title); ?>"
                     class="w-full h-auto rounded-lg shadow-lg">
            </div>
        </div>
    <?php endif; ?>
    
    
    <div class="container mx-auto px-4 pb-12">
        <div class="max-w-4xl mx-auto">
            <div class="prose prose-lg max-w-none">
                <?php echo $post->content; ?>

            </div>
            
            
            <?php if($post->type === 'gallery'): ?>
                
                <?php
                    \Log::info('=== FRONTEND GALLERY DEBUG ===');
                    \Log::info('Post ID: ' . $post->id);
                    \Log::info('Post Type: ' . $post->type);
                    \Log::info('Gallery Images Raw: ' . $post->getRawOriginal('gallery_images'));
                    \Log::info('Gallery Images Cast: ', ['gallery_images' => $post->gallery_images]);
                    \Log::info('Gallery Images Count: ' . (is_array($post->gallery_images) ? count($post->gallery_images) : 'not array'));
                ?>
                
                <?php if($post->gallery_images && count($post->gallery_images) > 0): ?>
                    <div class="mt-12 pt-8 border-t border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-6">Gallery (<?php echo e(count($post->gallery_images)); ?> images)</h3>
                        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                            <?php $__currentLoopData = $post->gallery_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    \Log::info('Image ' . $index . ': ' . $image);
                                ?>
                                <div class="group relative overflow-hidden rounded-lg shadow-md hover:shadow-lg transition-all duration-300">
                                    <img src="<?php echo e(asset('storage/' . $image)); ?>" 
                                         alt="Gallery image <?php echo e($index + 1); ?>"
                                         class="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                                         onerror="console.log('Failed to load image: <?php echo e(asset('storage/' . $image)); ?>')">
                                    
                                    
                                    <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                                        <div class="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                            <svg class="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="mt-12 pt-8 border-t border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-6">Gallery</h3>
                        <p class="text-gray-500">No gallery images found. Debug: gallery_images = <?php echo e(json_encode($post->gallery_images)); ?></p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            
            <?php if($post->tags): ?>
                <div class="mt-12 pt-8 border-t border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Tags</h3>
                    <div class="flex flex-wrap gap-2">
                        <?php $__currentLoopData = explode(',', $post->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="inline-block bg-gray-100 text-gray-700 text-sm px-3 py-1 rounded-full hover:bg-gray-200 transition-colors">
                                #<?php echo e(trim($tag)); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            
            <div id="shareMenu" class="hidden mt-8 p-6 bg-gray-50 rounded-lg">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Share this article</h3>
                <div class="flex flex-wrap gap-4">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(route('frontend.post', $post->slug))); ?>" 
                       target="_blank" 
                       class="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                        </svg>
                        Facebook
                    </a>
                    
                    <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(route('frontend.post', $post->slug))); ?>&text=<?php echo e(urlencode($post->title)); ?>" 
                       target="_blank" 
                       class="flex items-center px-4 py-2 bg-blue-400 text-white rounded-lg hover:bg-blue-500 transition-colors">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                        </svg>
                        Twitter
                    </a>
                    
                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(route('frontend.post', $post->slug))); ?>" 
                       target="_blank" 
                       class="flex items-center px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                        </svg>
                        LinkedIn
                    </a>
                    
                    <button onclick="copyToClipboard()" class="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                        </svg>
                        Copy Link
                    </button>
                </div>
            </div>
        </div>
    </div>
</article>


<?php if($relatedPosts && $relatedPosts->count() > 0): ?>
    <section class="bg-gray-50 py-16">
        <div class="container mx-auto px-4">
            <div class="max-w-6xl mx-auto">
                <h2 class="text-3xl font-bold text-gray-900 mb-8 text-center">Related Articles</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow group">
                            <?php if($relatedPost->featured_image): ?>
                                <div class="relative overflow-hidden">
                                    <img src="<?php echo e($relatedPost->featured_image_url); ?>" 
                                         alt="<?php echo e($relatedPost->title); ?>"
                                         class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300">
                                    
                                    <?php if($relatedPost->category): ?>
                                        <span class="absolute top-4 left-4 bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                                            <?php echo e($relatedPost->category->name); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="p-6">
                                <h3 class="text-lg font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                                    <a href="<?php echo e(route('frontend.post', $relatedPost->slug)); ?>" class="line-clamp-2">
                                        <?php echo e($relatedPost->title); ?>

                                    </a>
                                </h3>
                                
                                <p class="text-gray-600 mb-4 line-clamp-2">
                                    <?php echo e($relatedPost->excerpt ?: Str::limit(strip_tags($relatedPost->content), 100)); ?>

                                </p>
                                
                                <div class="flex items-center justify-between text-sm text-gray-500">
                                    <span><?php echo e($relatedPost->created_at->format('M d, Y')); ?></span>
                                    <span><?php echo e($relatedPost->views ?? 0); ?> views</span>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.prose {
    color: #374151;
    line-height: 1.75;
}

.prose h1, .prose h2, .prose h3, .prose h4, .prose h5, .prose h6 {
    color: #111827;
    font-weight: 700;
    margin-top: 2rem;
    margin-bottom: 1rem;
}

.prose h1 { font-size: 2.25rem; }
.prose h2 { font-size: 1.875rem; }
.prose h3 { font-size: 1.5rem; }
.prose h4 { font-size: 1.25rem; }

.prose p {
    margin-bottom: 1.5rem;
}

.prose a {
    color: #2563eb;
    text-decoration: underline;
}

.prose a:hover {
    color: #1d4ed8;
}

.prose ul, .prose ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
}

.prose li {
    margin-bottom: 0.5rem;
}

.prose blockquote {
    border-left: 4px solid #e5e7eb;
    padding-left: 1rem;
    margin: 1.5rem 0;
    font-style: italic;
    color: #6b7280;
}

.prose img {
    margin: 2rem 0;
    border-radius: 0.5rem;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}

.prose code {
    background-color: #f3f4f6;
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    font-size: 0.875rem;
}

.prose pre {
    background-color: #1f2937;
    color: #f9fafb;
    padding: 1rem;
    border-radius: 0.5rem;
    overflow-x: auto;
    margin: 1.5rem 0;
}

.prose pre code {
    background-color: transparent;
    padding: 0;
    color: inherit;
}

.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function toggleShareMenu() {
    const menu = document.getElementById('shareMenu');
    menu.classList.toggle('hidden');
}

function copyToClipboard() {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(function() {
        alert('Link copied to clipboard!');
    }, function(err) {
        console.error('Could not copy text: ', err);
    });
}

// Update view count
fetch('<?php echo e(route("api.posts.view", $post->id)); ?>', {
    method: 'POST',
    headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        'Content-Type': 'application/json',
    },
}).catch(error => console.log('View count update failed:', error));
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\webprofile\resources\views/frontend/post.blade.php ENDPATH**/ ?>