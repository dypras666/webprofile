<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    
    <title><?php echo $__env->yieldContent('title', $siteSettings['site_name'] ?? config('app.name', 'Laravel')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description', $siteSettings['seo_meta_description'] ?? 'Default description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords', $siteSettings['seo_meta_keywords'] ?? 'default, keywords'); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('author', $siteSettings['site_author'] ?? 'Admin'); ?>">
    
    
    <meta property="og:title" content="<?php echo $__env->yieldContent('og_title', $siteSettings['site_name'] ?? config('app.name')); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('og_description', $siteSettings['seo_meta_description'] ?? 'Default description'); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image', $siteSettings['seo_og_image'] ?? asset('images/default-og.jpg')); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:type" content="<?php echo $__env->yieldContent('og_type', 'website'); ?>">
    <meta property="og:site_name" content="<?php echo e($siteSettings['site_name'] ?? config('app.name')); ?>">
    
    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('twitter_title', $siteSettings['site_name'] ?? config('app.name')); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('twitter_description', $siteSettings['seo_meta_description'] ?? 'Default description'); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('twitter_image', $siteSettings['seo_og_image'] ?? asset('images/default-og.jpg')); ?>">
    
    
    <link rel="canonical" href="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">
    
    
    <link rel="icon" type="image/x-icon" href="<?php echo e($siteSettings['favicon'] ? asset('storage/' . $siteSettings['favicon']) : asset('favicon.ico')); ?>">
    
    
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />
    
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    
    
    <?php echo $__env->yieldPushContent('structured_data'); ?>
</head>
<body class="font-sans antialiased bg-gray-50">
    
    <?php echo $__env->make('components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <?php echo $__env->make('components.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    
    
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    
    <?php echo $__env->yieldPushContent('analytics'); ?>
</body>
</html><?php /**PATH E:\webprofile\resources\views/layouts/app.blade.php ENDPATH**/ ?>